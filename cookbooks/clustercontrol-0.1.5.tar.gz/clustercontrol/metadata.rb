name             'clustercontrol'
maintainer       'Severalnines AB'
maintainer_email 'ashraf@severalnines.com'
license          'All rights reserved'
description      'Installs/Configures Severalnines Clustercontrol'
long_description IO.read(File.join(File.dirname(__FILE__), 'README.md'))
version          '0.1.5'
