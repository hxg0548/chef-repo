clustercontrol CHANGELOG
========================

This file is used to list changes made in each version of the clustercontrol cookbook.

0.1.5
-----
- 7-Jun-2016 - Tested with ClusterControl v1.3.1 on Chef 12.

0.1.4
-----
- 8-Dec-2015 - Follow install-cc installation method. Tested with ClusterControl v1.2.11 on Chef 12. Support RHEL/CentOS 7, Debian 8 (Jessie).

0.1.3
-----
- 19-Dec-2014 - Add datadir into s9s_helper

0.1.2
-----
- 19-Dec-2014 - Fixed sudoer with password

0.1.1 
-----
- 19-Dec-2014 - Cleaning up and updated README

0.1.0
-----
- 17-Dec-2014 - Initial recipes based on ClusterControl v1.2.8

